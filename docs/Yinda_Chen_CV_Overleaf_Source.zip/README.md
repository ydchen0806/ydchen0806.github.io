# Yinda Chen | Bilingual Academic CV

A self-contained LaTeX project with Chinese and English academic CVs.

## Compile on Overleaf

1. Select New Project > Upload Project and upload this ZIP.
2. Set the main document to main.tex (Chinese by default).
3. Select XeLaTeX as the compiler.
4. Click Recompile.

For English, set the main document to resume_EN.tex, or change main.tex to:
~~~tex
\input{resume_EN.tex}
~~~

For Chinese, select resume_CN.tex, or use:
~~~tex
\input{resume_CN.tex}
~~~

## Compile locally

With a current TeX Live installation:
~~~bash
latexmk -xelatex -interaction=nonstopmode -halt-on-error resume_CN.tex
latexmk -xelatex -interaction=nonstopmode -halt-on-error resume_EN.tex
~~~

## Editable sources and assets

- resume_CN.tex and resume_EN.tex: authoritative CV content and formatting.
- resume.cls, zh_CN_fonts.sty, linespacing_fix.sty: local template dependencies.
- cyd.jpg and cydQRcode.jpeg: original portrait and contact QR image.
- main.tex and latexmkrc: compiler entrypoint and configuration.
- cast_ccf_2026_selection_proof.png: supporting award document; not required for typesetting.

The GitHub workflow compiles these sources without rewriting their content.
PDF hyperlinks point to the public homepage and original research resources.
