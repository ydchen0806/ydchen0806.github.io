# Yinda Chen | Bilingual Academic CV (October 2026)

Complete, flat-layout Overleaf project with Chinese and English LaTeX sources,
resume class, style dependencies, profile photo and QR code.

## Compile on Overleaf

1. Open Overleaf > New Project > Upload Project, and upload this ZIP.
2. **Main document:** `main.tex` (Chinese by default).
3. **Compiler:** XeLaTeX (Overleaf Menu > Settings > Compiler).
4. Click Recompile.

To compile the English version, change `main.tex` to:
```tex
\input{resume_EN.tex}
```
Alternatively set the Main document directly to `resume_EN.tex`.
To restore Chinese, use `\input{resume_CN.tex}` or select `resume_CN.tex`.

## Files
- `main.tex` — default Chinese entrypoint, switchable to English
- `resume_CN.tex`, `resume_EN.tex` — editable CV sources
- `resume.cls`, `zh_CN_fonts.sty`, `linespacing_fix.sty` — local template/style files
- `cyd.jpg`, `cydQRcode.jpeg` — profile photo and QR code
- `latexmkrc` — requests XeLaTeX
- `cast_ccf_2026_selection_proof.png` — CAST/CCF award proof (reference only)

The hyperlinks in the CV target the public homepage. All compilation
dependencies specific to the original CV are included as files.
